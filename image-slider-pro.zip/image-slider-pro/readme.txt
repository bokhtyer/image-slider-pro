
=== Image Slider PRO owlCarousel ===
Contributors: bokhtyer
Donate link: https://www.abiddev.com/
Tags:  slider, jquery-slider, wordpress-slider, owl-carousul, image-slider, image-slider-pro,
Requires at least: 4.0
Tested up to: 5.7
Stable tag: 1.0.0
Requires PHP: 5.6
License: GPLv2 or later

== Description ==
Image Slider Pro is very useful plugin to get amazing Slider features for your website .

==== USE SLIDER ===

Add This Shorcode Our Website
<code>[image_slider]</code>

Free Plugin Features:

 * Fully Responsive Slider Plugin
 * It is fully adjustable with any screen size or device resolution.
 * Slider Dots
 * Slider Nav
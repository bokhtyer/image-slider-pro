(function($){

    //Image Slider Pro Code

}(jQuery));